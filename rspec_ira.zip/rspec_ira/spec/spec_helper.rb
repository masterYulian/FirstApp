require_relative '../reviews'
require 'selenium-webdriver'
require 'rspec'

RSpec.configure do |config|

end
