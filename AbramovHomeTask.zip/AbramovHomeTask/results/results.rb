# frozen_string_literal: true

require '../results/results_data.rb'

results = ResultsData.new
results.getResults
